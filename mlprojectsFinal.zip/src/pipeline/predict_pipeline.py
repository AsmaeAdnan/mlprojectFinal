import os
import sys
import pandas as pd
from src.exception import CustomException
from src.utils import load_object


class PredictPipeline:
    def __init__(self):
        pass

    def predict(self,features):
        try:
            model_path=os.path.join("artifacts","model.pkl")
            preprocessor_path=os.path.join('artifacts','preprocessor.pkl')
            print("Before Loading")
            model=load_object(file_path=model_path)
            preprocessor=load_object(file_path=preprocessor_path)
            print("After Loading")
            data_scaled=preprocessor.transform(features)
            preds=model.predict(data_scaled)
            return preds
        
        except Exception as e:
            raise CustomException(e,sys)



class CustomData:
    def __init__(  self,
        OSEBuildingID: int,	
        DataYear: int,	
        BuildingType: str,	
        PrimaryPropertyType: str, 	
        PropertyName: str,	
        Address: str,	
        City: str,	
        State: str,	
        ZipCode: int,	
        TaxParcelIdentificationNumber: str,	
        CouncilDistrictCode: int,	
        Neighborhood: str,	
        Latitude: float,	
        Longitude: float,	
        YearBuilt: int,	
        NumberofBuildings: int,	
        NumberofFloors: int,	
        PropertyGFATotal: int,	
        PropertyGFAParking: int,	
        PropertyGFABuildings: int,	
        ListOfAllPropertyUseTypes: str,	
        LargestPropertyUseType: str,	
        LargestPropertyUseTypeGFA: int,	
        SecondLargestPropertyUseType: str,	
        SecondLargestPropertyUseTypeGFA: int,	
        ThirdLargestPropertyUseType: str,	
        ThirdLargestPropertyUseTypeGFA: int,	
        YearsENERGYSTARCertified: str,	
        ENERGYSTARScore: int,
        SiteEUI_kBtu_sf: int,	
        SiteEUIWN_kBtu_sf: int,	
        SourceEUI_kBtu_sf: int,	
        SourceEUIWN_kBtu_sf: int,	
        SiteEnergyUse_kBtu: int,	
        SiteEnergyUseWN_kBtu: int,	
        SteamUse_kBtu: int,	
        Electricity_kWh: int,	
        Electricity_kBtu: int,	
        NaturalGas_therms: int,	
        NaturalGas_kBtu: int,	
        DefaultData: int,	
        Comments: int,	
        ComplianceStatus: str,	
        Outlier: str,	
        TotalGHGEmissions: int,	
        GHGEmissionsIntensity: int
):

        self.OSEBuildingID = OSEBuildingID	
        self.DataYear = DataYear	
        self.BuildingType = BuildingType	
        self.PrimaryPropertyType = PrimaryPropertyType 	
        self.PropertyName = PropertyName	
        self.Address = Address	
        self.City = City	
        self.State = State	
        self.ZipCode = ZipCode	
        self.TaxParcelIdentificationNumber = TaxParcelIdentificationNumber	
        self.CouncilDistrictCode = CouncilDistrictCode	
        self.Neighborhood = Neighborhood	
        self.Latitude = Latitude	
        self.Longitude = Longitude	
        self.YearBuilt = YearBuilt	
        self.NumberofBuildings = NumberofBuildings
        self.NumberofFloors = NumberofFloors	
        self.PropertyGFATotal = PropertyGFATotal	
        self.PropertyGFAParking = PropertyGFAParking	
        self.PropertyGFABuildings = PropertyGFABuildings	
        self.ListOfAllPropertyUseTypes = ListOfAllPropertyUseTypes	
        self.LargestPropertyUseType = LargestPropertyUseType	
        self.LargestPropertyUseTypeGFA = LargestPropertyUseTypeGFA	
        self.SecondLargestPropertyUseType = SecondLargestPropertyUseType	
        self.SecondLargestPropertyUseTypeGFA = SecondLargestPropertyUseTypeGFA
        self.ThirdLargestPropertyUseType = ThirdLargestPropertyUseType
        self.ThirdLargestPropertyUseTypeGFA = ThirdLargestPropertyUseTypeGFA
        self.YearsENERGYSTARCertified = YearsENERGYSTARCertified
        self.ENERGYSTARScore = ENERGYSTARScore
        self.SiteEUI_kBtu_sf = SiteEUI_kBtu_sf
        self.SiteEUIWN_kBtu_sf = SiteEUIWN_kBtu_sf
        self.SourceEUI_kBtu_sf = SourceEUI_kBtu_sf
        self.SourceEUIWN_kBtu_sf = SourceEUIWN_kBtu_sf
        self.SiteEnergyUse_kBtu = SiteEnergyUse_kBtu
        self.SiteEnergyUseWN_kBtu = SiteEnergyUseWN_kBtu
        self.SteamUse_kBtu = SteamUse_kBtu
        self.Electricity_kWh = Electricity_kWh
        self.Electricity_kBtu = Electricity_kBtu
        self.NaturalGas_therms = NaturalGas_therms
        self.NaturalGas_kBtu = NaturalGas_kBtu
        self.DefaultData = DefaultData	
        self.Comments = Comments	
        self.ComplianceStatus = ComplianceStatus	
        self.Outlier = Outlier
        self.TotalGHGEmissions = TotalGHGEmissions	
        self.GHGEmissionsIntensity = GHGEmissionsIntensity

    def get_data_as_data_frame(self):
        try:
            custom_data_input_dict = {
                "OSEBuildingID": [self.OSEBuildingID],
                "DataYear": [self.DataYear],	
                "BuildingType": [self.BuildingType],	
                "PrimaryPropertyType": [self.PrimaryPropertyType],	
                "PropertyName": [self.PropertyName],	
                "Address": [self.Address],	
                "City": [self.City],	
                "State": [self.State],	
                "ZipCode": [self.ZipCode],	
                "TaxParcelIdentificationNumber": [self.TaxParcelIdentificationNumber],	
                "CouncilDistrictCode": [self.CouncilDistrictCode],	
                "Neighborhood": [self.Neighborhood],	
                "Latitude": [self.Latitude],	
                "Longitude": [self.Longitude],	
                "YearBuilt": [self.YearBuilt],	
                "NumberofBuildings": [self.NumberofBuildings],	
                "NumberofFloors": [self.NumberofFloors],	
                "PropertyGFATotal": [self.PropertyGFATotal],	
                "PropertyGFAParking": [self.PropertyGFAParking],	
                "PropertyGFABuilding(s)": [self.PropertyGFABuildings],	
                "ListOfAllPropertyUseTypes": [self.ListOfAllPropertyUseTypes],	
                "LargestPropertyUseType": [self.LargestPropertyUseType],	
                "LargestPropertyUseTypeGFA": [self.LargestPropertyUseTypeGFA],	
                "SecondLargestPropertyUseType": [self.SecondLargestPropertyUseType],	
                "SecondLargestPropertyUseTypeGFA": [self.SecondLargestPropertyUseTypeGFA],	
                "ThirdLargestPropertyUseType": [self.ThirdLargestPropertyUseType],	
                "ThirdLargestPropertyUseTypeGFA": [self.ThirdLargestPropertyUseTypeGFA],	
                "YearsENERGYSTARCertified": [self.YearsENERGYSTARCertified],	
                "ENERGYSTARScore": [self.ENERGYSTARScore],
                "SiteEUI(kBtu/sf)":	[self.SiteEUI_kBtu_sf],
                "SiteEUIWN(kBtu/sf)": [self.SiteEUIWN_kBtu_sf],	
                "SourceEUI(kBtu/sf)": [self.SourceEUI_kBtu_sf],	
                "SourceEUIWN(kBtu/sf)": [self.SourceEUIWN_kBtu_sf],	
                "SiteEnergyUse(kBtu)": [self.SiteEnergyUse_kBtu],	
                "SiteEnergyUseWN(kBtu)": [self.SiteEnergyUseWN_kBtu],	
                "SteamUse(kBtu)": [self.SteamUse],	
                "Electricity(kWh)": [self.Electricity_kWh],	
                "Electricity(kBtu)": [self.Electricity_kBtu],	
                "NaturalGas(therms)": [self.NaturalGas_therms],	
                "NaturalGas(kBtu)":	[self.NaturalGas_kBtu],
                "DefaultData": [self.DefaultData],	
                "Comments":	[self.Comments],
                "ComplianceStatus": [self.ComplianceStatus],	
                "Outlier": [self.Outlier],	
                "TotalGHGEmissions": [self.TotalGHGEmissions],	
                "GHGEmissionsIntensity": [self.GHGEmissionsIntensity],
            }

            return pd.DataFrame(custom_data_input_dict)

        except Exception as e:
            raise CustomException(e, sys)

