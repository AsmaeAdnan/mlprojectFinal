from flask import Flask,request,render_template
import numpy as np
import pandas as pd

from sklearn.preprocessing import StandardScaler
from src.pipeline.predict_pipeline import CustomData,PredictPipeline

application=Flask(__name__)

app=application

## Route for a home page

@app.route('/')
def index():
    return render_template('index.html') 

@app.route('/predictdata',methods=['GET','POST'])
def predict_datapoint():
    if request.method=='GET':
        return render_template('home.html')
    else:
        data=CustomData(
            OSEBuildingID=request.form.get('OSEBuildingID'),
            DataYear=request.form.get('DataYear'),
            ZipCode=request.form.get('ZipCode'),
            CouncilDistrictCode=request.form.get('CouncilDistrictCode'),
            Latitude=float(request.form.get('Latitude')),
            Longitude=float(request.foRm.get('Longitude')),
            YearBuilt=request.form.get('YearBuilt'),
            NumberofBuildings=request.form.get('NumberofBuildings'),
            NumberofFloors=request.form.get('NumberofFloors'),
            PropertyGFATotal=request.form.get('PropertyGFATotal'),
            PropertyGFAParking=request.form.get('PropertyGFAParking'),
            PropertyGFABuildings=request.form.get('PropertyGFABuildings'),
            LargestPropertyUseTypeGFA=request.form.get('LargestPropertyUseTypeGFA'),
            SecondLargestPropertyUseTypeGFA=request.form.get('SecondLargestPropertyUseTypeGFA'),
            ThirdLargestPropertyUseTypeGFA=request.form.get('ThirdLargestPropertyUseTypeGFA'),
            ENERGYSTARScore=request.form.get('ENERGYSTARScore'),
            SiteEUI_kBtu_sf=request.form.get('SiteEUI(kBtu/sf)'), 
            SiteEUIWN_kBtu_sf=request.form.get('SiteEUIWN(kBtu/sf)'), 
            SourceEUI_kBtu_sf=request.form.get('SourceEUI(kBtu/sf)'), 
            SourceEUIWN_kBtu_sf=request.form.get('SourceEUIWN(kBtu/sf)'), 
            SiteEnergyUse_kBtu=request.form.get('SiteEnergyUse(kBtu)'), 
            SiteEnergyUseWN_kBtu=request.form.get('SiteEnergyUseWN(kBtu)'), 
            SteamUse_kBtu=request.form.get('SteamUse(kBtu)'), 
            Electricity_kWh=request.form.get('Electricity(kWh)'), 
            Electricity_kBtu=request.form.get('Electricity(kBtu)'), 
            NaturalGas_therms=request.form.get('NaturalGas(therms)'), 
            NaturalGas_kBtu=request.form.get('NaturalGas(kBtu)'), 
            DefaultData=request.form.get('DefaultData'), 
            Comments=request.form.get('Comments'), 
            BuildingType=request.form.get('BuildingType'), 
            PrimaryPropertyType=request.form.get('PrimaryPropertyType'), 
            PropertyName=request.form.get('PropertyName'), 
            Address=request.form.get('Address'), 
            City=request.form.get('City'), 
            State=request.form.get('State'), 
            TaxParcelIdentificationNumber=request.form.get('TaxParcelIdentificationNumber'), 
            Neighborhood=request.form.get('Neighborhood'), 
            ListOfAllPropertyUseTypes=request.form.get('ListOfAllPropertyUseTypes'), 
            LargestPropertyUseType=request.form.get('LargestPropertyUseType'), 
            SecondLargestPropertyUseType=request.form.get('SecondLargestPropertyUseType'), 
            ThirdLargestPropertyUseType=request.form.get('ThirdLargestPropertyUseType'), 
            YearsENERGYSTARCertified=request.form.get('YearsENERGYSTARCertified'), 
            ComplianceStatus=request.form.get('ComplianceStatus'), 
            Outlier=request.form.get('Outlier')

        )
        pred_df=data.get_data_as_data_frame()
        print(pred_df)
        print("Before Prediction")

        predict_pipeline=PredictPipeline()
        print("Mid Prediction")
        results=predict_pipeline.predict(pred_df)
        print("after Prediction")
        return render_template('home.html',results=results[0])
    

if __name__=="__main__":
    app.run(host="0.0.0.0")        


